<?php
/**
 * The template for displaying all pages
 *
 * @package Cozanet
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();
?>

<main id="main" class="site-main">
    <div class="page-container">
        <?php
        while ( have_posts() ) : the_post();
            the_content();
        endwhile; // End of the loop.
        ?>
    </div>
</main>

<?php
get_footer();
