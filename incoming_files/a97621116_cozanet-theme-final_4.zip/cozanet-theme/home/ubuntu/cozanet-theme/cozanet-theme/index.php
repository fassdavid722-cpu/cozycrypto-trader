<?php
/**
 * The main template file
 *
 * @package Cozanet
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// If it's any page other than the front page, use the page.php template
if ( is_page() && ! is_front_page() ) {
    get_template_part( 'page' );
    return;
}

// Otherwise, load the React single-page application for the front page
get_header();
?>

<div id="root" class="cozanet-app">
    <!-- React App will render here -->
</div>

<?php
get_footer();
