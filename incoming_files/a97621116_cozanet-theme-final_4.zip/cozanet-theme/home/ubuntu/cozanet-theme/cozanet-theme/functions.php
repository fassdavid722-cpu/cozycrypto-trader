<?php
/**
 * Cozanet Theme Functions
 * 
 * @package Cozanet
 */

// 1. SECURITY: Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

define( 'COZANET_THEME_VERSION', '1.0.2' );

/**
 * 2. THEME SETUP
 */
function cozanet_setup() {
    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );
    
    // Enable support for Post Thumbnails
    add_theme_support( 'post-thumbnails' );
    
    // Custom Logo Support
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ) );
}
add_action( 'after_setup_theme', 'cozanet_setup' );

/**
 * 3. DYNAMIC ASSET LOADER (CRITICAL FIX)
 * Automatically finds the correct file hash (e.g., index-BP6Ss8tT.js)
 * so you don't get 404 errors when you rebuild your app.
 */
function cozanet_scripts() {
    $theme_path = get_template_directory();
    $theme_uri  = get_template_directory_uri();
    
    // CHECK YOUR PATH: Vite usually builds to 'assets' or 'assets/js'
    $js_dir = '/assets/js/'; 
    
    // A. Find the JS file automatically
    $js_files = glob( $theme_path . $js_dir . 'index-*.js' );
    $js_file  = $js_files ? basename( $js_files[0] ) : null;

    // B. Find the CSS file automatically
    $css_files = glob( $theme_path . $js_dir . 'index-*.css' );
    $css_file  = $css_files ? basename( $css_files[0] ) : null;

    // C. Enqueue CSS (If found)
    if ( $css_file ) {
        wp_enqueue_style(
            'cozanet-react-style',
            $theme_uri . $js_dir . $css_file,
            array(),
            COZANET_THEME_VERSION
        );
    }

    // D. Enqueue JS (If found)
    if ( $js_file ) {
        wp_enqueue_script(
            'cozanet-react-core',
            $theme_uri . $js_dir . $js_file,
            array(), 
            COZANET_THEME_VERSION,
            array( 'strategy' => 'defer' ) // Use defer for modern React apps
        );
        
        // E. Pass Data to React (Prevents "undefined" crashes)
        wp_localize_script('cozanet-react-core', 'wpSettings', array(
            'rootUrl' => get_site_url(),
            'themeUrl' => get_template_directory_uri(),
            'apiUrl'   => home_url('/wp-json/wp/v2/'),
            'assetsUrl' => get_template_directory_uri() . '/assets',
            'contactEmail' => 'info@cozanet.net'
        ));
    }
}
add_action( 'wp_enqueue_scripts', 'cozanet_scripts' );

/**
 * 4. WIDGETS & EXTRAS
 */
function cozanet_widgets_init() {
    register_sidebar( array(
        'name'          => 'Primary Sidebar',
        'id'            => 'primary-sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'cozanet_widgets_init' );

// Disable Admin Bar on Frontend for cleaner Look
add_filter( 'show_admin_bar', '__return_false' );

/**
 * 5. CUSTOM REST API ENDPOINTS (Optional)
 * Add custom endpoints here if needed for the React app
 */
function cozanet_register_rest_routes() {
    // Example: register_rest_route( 'cozanet/v1', '/settings', array(...) );
}
add_action( 'rest_api_init', 'cozanet_register_rest_routes' );
