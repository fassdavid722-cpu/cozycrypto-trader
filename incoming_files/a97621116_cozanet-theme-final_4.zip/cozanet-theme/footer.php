<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #page div and all content after.
 *
 * @package Cozanet
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
    </div><!-- #page -->
    <?php wp_footer(); ?>
</body>
</html>
