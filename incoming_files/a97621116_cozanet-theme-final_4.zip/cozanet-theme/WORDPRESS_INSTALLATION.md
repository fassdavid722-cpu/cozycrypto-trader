# Cozanet WordPress Theme - Installation Guide

## Overview
This is a complete WordPress theme built from your React application. It includes all compiled assets (CSS, JavaScript, and images) ready to be deployed on WordPress.

## 📋 What's Included
- **style.css** - Theme metadata and basic styling
- **functions.php** - Theme functionality and asset loading
- **index.php** - Main template file
- **header.php** - Header template
- **footer.php** - Footer template
- **assets/js/** - Compiled JavaScript and CSS from React build
- **assets/images/** - All optimized images

## 🚀 Installation Steps

### Step 1: Access Your WordPress Admin Panel
1. Go to your WordPress dashboard (yoursite.com/wp-admin)
2. Log in with your credentials

### Step 2: Upload the Theme
**Option A: Via WordPress Admin (Easiest)**
1. Go to **Appearance → Themes**
2. Click **"Add New"** button
3. Click **"Upload Theme"** button
4. Click **"Choose File"** and select the `cozanet-theme.zip` file
5. Click **"Install Now"**
6. Once installed, click **"Activate"**

**Option B: Via FTP (If you have FTP access)**
1. Extract the `cozanet-theme.zip` file on your computer
2. Connect to your server via FTP
3. Navigate to `/wp-content/themes/`
4. Upload the `cozanet-theme` folder
5. Go to WordPress admin → Appearance → Themes
6. Find "Cozanet" and click "Activate"

### Step 3: Verify Installation
1. Visit your website's homepage
2. You should see the Cozanet website fully loaded
3. Test all navigation links
4. Verify images are loading correctly
5. Check that animations are working

## ⚙️ Configuration

### Site Title and Tagline
1. Go to **Settings → General**
2. Update "Site Title" to your preferred name
3. Update "Tagline" if desired
4. Save changes

### Homepage Settings
1. Go to **Settings → Reading**
2. Under "Your homepage displays", select "A static page"
3. Create a new page called "Home" (or use existing)
4. Set it as your homepage
5. Save changes

### Menus (Optional)
1. Go to **Appearance → Menus**
2. Create a new menu if desired
3. Add menu items
4. Assign to "Primary Menu" location
5. Save

## 🔧 Troubleshooting

### Issue: Theme appears broken or unstyled
**Solution:**
1. Go to **Appearance → Themes**
2. Click "Activate" on Cozanet theme again
3. Clear your browser cache (Ctrl+Shift+Delete)
4. Hard refresh the page (Ctrl+Shift+R)

### Issue: Images not loading
**Solution:**
1. Check that the `assets/images/` folder was uploaded correctly
2. Verify file permissions (should be 644 for files, 755 for folders)
3. Go to **Settings → Permalinks** and click "Save Changes" to refresh

### Issue: JavaScript not working or animations not showing
**Solution:**
1. Check browser console for errors (F12 → Console tab)
2. Verify that `assets/js/index-BP6Ss8tT.js` is loaded
3. Try disabling other plugins temporarily
4. Clear WordPress cache if using a caching plugin

### Issue: White screen of death
**Solution:**
1. Enable WordPress debugging:
   - Edit `wp-config.php`
   - Add: `define('WP_DEBUG', true);`
   - Check `/wp-content/debug.log` for errors
2. Increase PHP memory limit in `wp-config.php`:
   - Add: `define('WP_MEMORY_LIMIT', '256M');`

## 📱 Mobile Responsiveness
The theme is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones

Test on different devices to ensure proper display.

## 🎨 Customization

### Changing Colors
The theme uses Tailwind CSS. To modify colors:
1. You would need to rebuild the React app
2. Or use WordPress plugins like "Custom CSS" to override styles

### Adding Custom Content
1. Create new pages in WordPress
2. Use the WordPress editor to add content
3. The theme will display your content alongside the React app

### Modifying the React App
If you need to modify the React application:
1. Edit the source files in the original React project
2. Run `npm run build`
3. Copy the new compiled files from `dist/assets/` to theme's `assets/js/`
4. Replace the old files in the theme

## 📊 Performance Tips

1. **Enable Caching:**
   - Install a caching plugin like WP Super Cache or W3 Total Cache
   - Configure to cache static assets

2. **Optimize Images:**
   - Use an image optimization plugin like Smush
   - Ensure images are properly sized

3. **Minify Assets:**
   - The React build is already minified
   - Consider using a minification plugin for additional CSS/JS

4. **Use a CDN:**
   - Consider using Cloudflare or similar CDN
   - Serves assets from locations closer to your users

## 🔐 Security

1. **Keep WordPress Updated:**
   - Regularly update WordPress core, themes, and plugins

2. **Use Security Plugins:**
   - Install Wordfence or similar security plugin
   - Enable two-factor authentication

3. **Backup Regularly:**
   - Use a backup plugin like UpdraftPlus
   - Store backups off-site

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Review WordPress documentation: https://wordpress.org/support/
3. Check theme compatibility with your WordPress version
4. Ensure PHP version is 7.4 or higher

## ✅ Verification Checklist

After installation, verify:
- [ ] Theme is activated
- [ ] Homepage displays correctly
- [ ] All images load
- [ ] Navigation works
- [ ] Animations play smoothly
- [ ] Mobile view is responsive
- [ ] No console errors (F12)
- [ ] Performance is acceptable

---

**Theme Version:** 1.0.0
**WordPress Requirement:** 5.0+
**PHP Requirement:** 7.4+
**Status:** Ready for production deployment
